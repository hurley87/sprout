# Evie's Sparkle Tour — Issue #94

**Route:** `/concert`  
**Suggested asset location:** `public/counting/concert/`

Individual SVG images are transparent, viewBox `0 0 320 320`. Backgrounds are
1600 × 900 SVGs, with a deliberately empty center so foreground counting targets
can be independently placed. All artwork here is original and does **not** depict
Taylor Swift or include copyrighted music or logos.

| Round | Count | Foreground asset(s) |
|---|---:|---|
| Microphone | 1 | `microphone.svg` |
| Guitars | 2 | `guitar-pink.svg`, `guitar-lavender.svg` |
| Friendship bracelets | 3 | Three `bracelet-*.svg` |
| Stars | 3 | Three separately placed `star.svg` |
| Stage lights | 4 | Four `stage-light-*.svg` |
| Beads | 5 | Five `bead-*.svg` |
| Butterflies | 6 | Six instances of `butterfly-*.svg` (positions/colours may vary) |

**Backdrops:** `concert-stage.svg` for counting, `concert-finale.svg` for celebration.
There are intentionally no extra guitars, stars, spotlights, or other countable
objects pre-rendered into the counting background. Keep objects in the foreground.

The visual style is pastel rose / lavender / gold, with friendly outlined shapes.
The number of objects is controlled by the authored lesson, **not the background**.

`preview.png` is a review sheet only; never place it in a lesson scene.
