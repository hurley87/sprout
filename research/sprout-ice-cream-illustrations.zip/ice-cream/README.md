# Evie's Ice Cream Shop — Issue #95

**Route:** `/ice-cream`  
**Suggested asset location:** `public/ice-cream/`

Transparent individual SVG objects use viewBox `0 0 320 320`. Backdrops use
1600 × 900 SVGs. Put countable objects on top in the application so the model
cannot add objects independently or accidentally read decorative duplicates.

**Objects:** `cone.svg`, `scoop-pink.svg`, `scoop-yellow.svg`, `scoop-blue.svg`,
`scoop-lavender.svg`, `scoop-mint.svg`, `scoop-chocolate.svg`, `cherry.svg`,
`sprinkles.svg`.

**Backgrounds:** `shop-counter.svg` and `shop-finale.svg`. Neither background
has any cones or scoops; the scene renderer must draw them explicitly.

**Suggested scene use:**
1. Place two separate `cone.svg` objects, ask how many.
2. Show separated pink and yellow scoops, ask which one is pink.
3. Show two pink scoops and one yellow distractor; ask how many **pink** scoops.
4. Build a cone using separate scoop layers, revealing pink first, then yellow
   only when the correct spoken step is accepted. The sprite is the same SVG;
   the app changes its position. Hide/cover the cone opening with the first scoop.
5. Show one cone and three separate scoops stacked with overlap, ask the total.
6. Finale: completed order with optional `cherry.svg`, `sprinkles.svg`, and
   background confetti.

For layered orders, draw the bottom scoop slightly above the cone rim and each
subsequent scoop higher. Different scoops have strong outlines and distinct
colours. **No text is baked into the SVG artwork.**

`preview.png` is a review sheet only; never place it in a lesson scene.
